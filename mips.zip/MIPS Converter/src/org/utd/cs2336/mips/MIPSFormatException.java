/**
 * UTD CS 2336
 * Assignment 4 - Spring 2016
 * @author Parijat Singh
 * email: parijat.sigh@gmail.com * 
 */

package org.utd.cs2336.mips;
public class MIPSFormatException extends Exception {

	public MIPSFormatException(String message){
		super(message);
	}
}

